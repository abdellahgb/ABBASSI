                           ABBASSI YA DAWLA 














 






  
                               YDEK FIH
  
